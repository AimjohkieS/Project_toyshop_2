<div class="list-group">
	
	<a href="../index.php" class="list-group-item list-group-item-action">เว็บหลัก</a>
	<a href="admin.php" class="list-group-item list-group-item-action">จัดการผู้ดูแลระบบ</a>
	<a href="member.php" class="list-group-item list-group-item-action">จัดการสมาชิก</a>
	<a href="type.php" class="list-group-item list-group-item-action">จัดการประเภทสินค้า</a>
	<a href="product.php" class="list-group-item list-group-item-action">จัดการสินค้า</a>
	<!--อยู่ข้่าง1อันดับ ..-->
	<a href="../logout.php" class="list-group-item list-group-item-action" onclick="return confirm('คุณต้องการออกจากระบบหรือไม่ ?')">ออกจากระบบ</a>
</div>