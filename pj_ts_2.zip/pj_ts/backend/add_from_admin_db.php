<?php
include('connect.php');

$admin_user = $_POST['admin_user'];
$admin_pass = sha1($_POST['admin_pass']);
$admin_name = $_POST['admin_name'];


  $check = "
  SELECT  admin_user
  FROM tbl_admin  
  WHERE m_user = '$admin_user' 
  ";
    $result1 = mysqli_query($con, $check) or die(mysqli_error());
    $num=mysqli_num_rows($result1);

    if($num > 0)
    {
    echo "<script>";
    echo "alert(' ข้อมูลซ้ำ กรุณาเพิ่มใหม่อีกครั้ง !');";
    echo "window.history.back();";
    echo "</script>";
    }else{


$sql ="INSERT INTO tbl_admin
    
    (m_user,  m_pass, m_name) 

    VALUES 

    ('$admin_user', '$admin_pass', '$admin_name')";
    
    $result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
    mysqli_close($con);
  }
    
    if($result){
      echo "<script>";
      echo "alert('เพิ่มข้อมูลเรียบร้อย');";
      echo "window.location ='admin.php'; ";
      echo "</script>";
    } else {
      
      echo "<script>";
      echo "alert('ERROR!');";
      echo "window.location ='admin.php'; ";
      echo "</script>";
    }
?>